// bootstrap.mjs

import Container from '@teqfw/di';

const container = new Container();

container.addNamespaceRoot(
    'App_',
    new URL('./src/App/', import.meta.url).href,
    '.mjs'
);

const greet = await container.get('App_Greet$');

console.log(greet('  aLEX  '));
