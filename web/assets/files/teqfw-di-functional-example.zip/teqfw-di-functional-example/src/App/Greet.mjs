// src/App/Greet.mjs

export const __deps__ = {
    default: {
        config: 'App_Config$',
        formatName: 'App_FormatName$',
    },
};

export default ({config, formatName}) =>
    (name) => `${config.greeting}, ${formatName(name)}${config.punctuation}`;
