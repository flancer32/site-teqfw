// src/App/Config.mjs

export default () => ({
    greeting: 'Hello',
    punctuation: '!',
});
