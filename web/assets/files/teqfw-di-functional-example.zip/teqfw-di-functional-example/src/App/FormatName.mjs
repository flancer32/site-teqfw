// src/App/FormatName.mjs

export default () => (name) => {
    const value = name.trim().toLowerCase();
    return value.charAt(0).toUpperCase() + value.slice(1);
};
